import pygame
import os
import math
from settings import BLACK 

TOWER_IMAGE = pygame.image.load(os.path.join("images", "rapid_test.png"))


class Circle:
    def __init__(self, center, radius):
        self.center = center
        self.radius = radius
        self.transparency = 120#控制透明度的變數

    def collide(self, enemy):
        """
         check whether the enemy is in the circle (attack range), if the enemy is in range return True
        :param enemy: Enemy() object
        :return: Bool
        """
        self.x, self.y = enemy.get_pos()#先取得病毒的位置訊息
        self.distance_enemy= math.sqrt((self.x-self.center[0])**2 + (self.y- self.center[1])**2)#計算出病毒與防禦塔之間的距離
        if(self.distance_enemy<=self.radius):#若self.distance_enemy小於攻擊距離(self.radius)則返回true
            return True
        else:
            return False

    def draw_transparent(self, win):
        """
         draw the tower effect range, which is a transparent circle.
        :param win: window surface
        :return: None
        """
        self.transparent_surface = pygame.Surface((self.radius*2,self.radius*2), pygame.SRCALPHA)
        #先設定一個長高與圓形直徑相等的正方形背景,若要加入具有透明度的圖像需先加入pygame.SRCALPHA
        self.transparent_surface_pos=(self.center[0]-self.radius ,self.center[1]-self.radius)
        #設定這個正方形背景的位置,其x,y坐標為防禦塔中心的x,y坐標各與圓形的半徑相減
        pygame.draw.circle(self.transparent_surface, (110,110,110,self.transparency), (self.radius,self.radius), self.radius)
        #把圓形先加到背景上,(110,110,110)為灰色,因為背景的長高為圓形半徑的兩倍,所以圓形的位置與半徑直接代入self.radius即可
        win.blit(self.transparent_surface,self.transparent_surface_pos)#再把已加上半透明圓形的正方形背景直接放到主熒幕上
        pygame.display.update() 


class Tower:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(TOWER_IMAGE, (70, 70))  # image of the tower
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # center of the tower
        self.range = 150  # tower attack range
        self.damage = 2   # tower damage
        self.range_circle = Circle(self.rect.center, self.range)  # attack range circle (class Circle())
        self.cd_count = 0  # used in self.is_cool_down()
        self.cd_max_count = 60  # used in self.is_cool_down()
        self.is_selected=False  # the state of whether the tower is selected
        self.type = "tower"
        self.shot_on=True#用於判斷防禦塔是否已準備攻擊
 

    def is_cool_down(self):
        """
         Return whether the tower is cooling down
        (1) Use a counter to computer whether the tower is cooling down (( self.cd_count
        :return: Bool
        """
        if(self.shot_on):#若防禦塔已準備好做攻擊了,則回傳True
            return True
        else:#若防禦塔未準備攻擊,則做倒數冷卻的動作
            self.cd_count+=1
            if(self.cd_count==self.cd_max_count):
               self.shot_on=True#若倒數完畢則把self.shot_on設為True,下一次迴圈時便可做攻擊
               self.cd_count=0#把冷卻倒數歸零
            return False#冷卻倒數時會先回傳False           
        

    def attack(self, enemy_group):
        """
        Attack the enemy.
        (1) check the the tower is cool down ((self.is_cool_down()
        (2) if the enemy is in attack range, then enemy get hurt. ((Circle.collide(), enemy.get_hurt()
        :param enemy_group: EnemyGroup()
        :return: None
        """
        enemy_team = enemy_group.get()#先得到已放出的病毒隊伍數據    
        if(self.is_cool_down() and enemy_team):#當冷卻結束且病毒隊伍不為空集合時繼續做以下的判斷
            for i in range(0,len(enemy_team)):#逐個搜索範圍內的病毒個體,每一次迴圈都會搜索最接近的病毒個體并進行攻擊
                if(self.range_circle.collide(enemy_team[i])):
                    enemy_team[i].get_hurt(self.damage)#搜索到病毒個體后進行攻擊
                    self.shot_on=False#攻擊后把self.shot_on設為False,防禦塔進入冷卻
                    break #當搜索到最接近的病毒個體時會結束迴圈,不再繼續搜索病毒,防止防禦塔同時攻擊多個病毒

    def is_clicked(self, x, y):
        """
         Return whether the tower is clicked
         If the mouse position is on the tower image, return True
        :param x: mouse pos x
        :param y: mouse pos y
        :return: Bool
        """
        pos_of_mouse= math.sqrt((x-self.rect.center[0])**2 + (y- self.rect.center[1])**2)#計算出滑鼠當前位置與防禦塔中心點的距離
        if(pos_of_mouse<=35):#因為防禦塔圖形的長高為70,所以判斷滑鼠是否在防禦塔半徑35內即可
            return True
        else:
            return False
    

    def get_selected(self, is_selected):
        """
        Bonus) Change the attribute self.is_selected
        :param is_selected: Bool
        :return: None
        """
        self.is_selected = is_selected

    def draw(self, win):
        """
        Draw the tower and the range circle
        :param win:
        :return:
        """
        # draw range circle
        if self.is_selected:
            self.range_circle.draw_transparent(win)
        # draw tower
        win.blit(self.image, self.rect)


class TowerGroup:
    def __init__(self):
        self.constructed_tower = [Tower(250, 380), Tower(420, 400), Tower(600, 400)]

    def get(self):
        return self.constructed_tower

